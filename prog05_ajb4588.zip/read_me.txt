/////////////////////////UT POD//////////////////
instructions: 
1. download file (obviously)
2. unzip file
3. write "make prog5_ajb4588" in the command line
4. "./prog5_ajb4588"
5. Enter a number between 0 and 512 to set the amount of memory in the UTpod 
	- If number is out of this range, it will automatically be set to 512

//// addSong
to use this function you must first use the song constructor from song.cpp
do not add songs without having all of the information ( artist, Title, memory).

//// removeSong
use this function to remove a song, the artist, title and memory MUST be given for this function to work properly.

//// shuffle 
use this function to shuffle songs in random order

//// sortSongList
use this function to sort songs by artist, title, and memory in that order.

//// getTotalMemory 
use this function to get the total amount of memory in the UT pod

//// getRemainingMemory 
use this function to get the remaining amount of memory in the UT pod (Total memory - memory taken up by songs)

thanks for actually reading the read_me


